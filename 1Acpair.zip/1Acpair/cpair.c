#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include <ctype.h>

#define READ_END 0
#define WRITE_END 1

typedef struct {
    float x, y;
} Point;

typedef struct {
    Point p1, p2;
    float distance;
} ClosestPair;

int split_at_space(const char *input, char **firstPart, char **secondPart) {
    // Find the first space in the input
    char *spacePtr = strchr(input, ' ');
    if (spacePtr == NULL) {
        return 0; // No space found
    }

    // Allocate memory for the first part and copy the substring before the space
    *firstPart = malloc(spacePtr - input + 1);
    if (*firstPart == NULL) {
        return 0; // Memory allocation failed
    }
    strncpy(*firstPart, input, spacePtr - input);
    (*firstPart)[spacePtr - input] = '\0'; // Null-terminate the first part

    // Allocate memory for the second part and copy the substring after the space
    *secondPart = strdup(spacePtr + 1);
    if (*secondPart == NULL) {
        free(*firstPart); // Clean up the first part allocation
        return 0; // Memory allocation failed
    }

    return 1; // Success
}

int is_float(const char *str) {
    char *endptr;
    errno = 0; // To distinguish success/failure after the call

    // strtod converts the initial part of str to a double
    double val = strtod(str, &endptr);

    // Check for various possible errors
    if ((errno == ERANGE && (val == HUGE_VAL || val == -HUGE_VAL)) || (errno != 0 && val == 0)) {
        // Conversion error (e.g., out of range for a double)
        return 0;
    }

    if (endptr == str) {
        // No digits were found
        return 0;
    }

    // Check if the entire string was consumed by strtod
    while (*endptr) {
        if (!isspace((unsigned char)*endptr)) return 0; // Non-space characters remaining
        endptr++;
    }

    return 1; // String is a float
}

//, float *mean give here a mean and pas in oon
int read_points(Point **points) {
    int n = 0;
    int capacity = 10;  // Initial capacity for points array
    *points = malloc(capacity * sizeof(Point));

    if (!points) {
        perror("malloc");
        return -1;
    }


    char line[1024]; // Buffer to store the input line

    while (fgets(line, sizeof(line), stdin)) {
        char* n1;
        char* n2;
        split_at_space(line, &n1,  &n2);
        if (is_float(n1) !=1) {
            return -1;
        }

        if (is_float(n2) != 1) {
            return -1;
        }
        char *endptr;
        (*points)[n].x = strtof(n1, &endptr);
        if (endptr == n1) {
            return -1;
        }
        (*points)[n].y = strtof(n2, &endptr);
        if (endptr == n2) {
            return -1;
        }
        n++;

        // Check if we need to expand the array
        if (n >= capacity) {
            capacity *= 2;
            *points = realloc(*points, capacity * sizeof(Point));
            if (!*points) {
                perror("realloc");
                return -1;
            }
        }
    }


    if (n == 0) {
        //no error print here
        fprintf(stderr, "No valid points were read from the input.\n");

        free(*points);
        return -1;
    }


    return n;
}


void write_result_to_stdout(ClosestPair closestPairResult) {
    write(STDOUT_FILENO, &closestPairResult, sizeof(ClosestPair));
}

ClosestPair read_result_from_pipe(int pipe_fd, int lsize, int rsize) {
    ClosestPair result;
    FILE *pipe_file = fdopen(pipe_fd, "r");
    if (!pipe_file) {
        perror("fdopen");
        exit(EXIT_FAILURE);
    }
    if (fscanf(pipe_file, "%f %f %f %f", &result.p1.x, &result.p1.y, &result.p2.x, &result.p2.y) ==
        -1) {
        //no error print here
        fprintf(stderr, "Failed to read result from pipe %d %d \n", lsize, rsize);
        exit(EXIT_FAILURE);
    }
//    ClosestPair cp = bruteForce(points,3);
    result.p1.x = truncf(result.p1.x * 1000) / 1000;
    result.p1.y = truncf(result.p1.y * 1000) / 1000;
    result.p2.x = truncf(result.p2.x * 1000) / 1000;
    result.p2.y = truncf(result.p2.y * 1000) / 1000;
    fclose(pipe_file);
    return result;
}

void create_pipe(int pipe_fd[2]) {
    if (pipe(pipe_fd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }
}


void
close_unused_ends_of_pipes_in_parent(int pipe_left[2], int pipe_right[2], int result_left[2], int result_right[2]) {

    close(result_left[WRITE_END]);
    close(result_right[WRITE_END]);
}

void setup_child(int pipe_in[2], int pipe_out[2]) {
    // Redirecting standard input to read from the pipe
    if (dup2(pipe_in[READ_END], STDIN_FILENO) == -1) {
        perror("dup2");
        exit(EXIT_FAILURE);
    }

    // Redirecting standard output to write to the pipe
    if (dup2(pipe_out[WRITE_END], STDOUT_FILENO) == -1) {
        perror("dup2");
        exit(EXIT_FAILURE);
    }

    // Closing the ends of the pipes that are now unused
    close(pipe_in[READ_END]); // Already duplicated to STDIN, so can be closed
    close(pipe_out[WRITE_END]); // Already duplicated to STDOUT, so can be closed
}

void create_process(pid_t *pid) {

    if ((*pid = fork()) == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
}


void write_data_to_pipe(int pipe_fd[2], Point *points, int size) {
    FILE *pipe_file = fdopen(pipe_fd[WRITE_END], "w");
    if (!pipe_file) {
        perror("fdopen");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < size; i++) {
        //fprintf(stderr,"%d\n",i);
        fprintf(pipe_file, "%.3f %.3f\n", points[i].x, points[i].y);
    }
    fclose(pipe_file);
}

void execute_child_program(void) {
    execlp("./cpair", "cpair", (char *) NULL);
    perror("execlp");
    exit(EXIT_FAILURE);
}


float dist(Point p1, Point p2) {
    return (p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y);
}

ClosestPair findClosestPairArbitrary(Point *points1, int size1, Point *points2, int size2) {
    ClosestPair closestPairResult;
    closestPairResult.distance = FLT_MAX; // Initialize with the maximum float value

    for (int i = 0; i < size1; ++i) {
        for (int j = 0; j < size2; ++j) {
            float currentDistance = dist(points1[i], points2[j]);
            if (currentDistance < closestPairResult.distance) {
                closestPairResult.distance = currentDistance;
                closestPairResult.p1 = points1[i];
                closestPairResult.p2 = points2[j];
            }
        }
    }

    return closestPairResult;
}


ClosestPair findClosestPair(Point cl_p1, Point cl_p2, Point cr_p1, Point cr_p2) {
    ClosestPair closestPairResult;
    float minimumDistance = FLT_MAX; // Initialize with the maximum float value

    Point points[] = {cl_p1, cl_p2, cr_p1, cr_p2};

    for (int i = 0; i < 4 - 1; ++i) {
        for (int j = i + 1; j < 4; ++j) {
            if (j != i) {
                float currentDistance = dist(points[i], points[j]);
                if (currentDistance < minimumDistance) {
                    minimumDistance = currentDistance;
                    closestPairResult.p1 = points[i];
                    closestPairResult.p2 = points[j];
                    closestPairResult.distance = currentDistance; // This is the squared distance
                }
            }

        }
    }

    return closestPairResult;
}

ClosestPair closestPair(Point P[], int n) {
    float meanX = 0;
    bool allXAreSame = true;
    bool allYAreSame = true;
    float firstX = P[0].x;
    float firstY = P[0].y;

    // Calculate meanX and check if all x-coordinates and y-coordinates are the same
    for (int i = 0; i < n; i++) {
        meanX += P[i].x;
        if (P[i].x != firstX) {
            allXAreSame = false;
        }
        if (P[i].y != firstY) {
            allYAreSame = false;
        }
    }
    meanX /= n;

    // Variables to handle y-coordinates if needed
    float meanY = 0;
    int leftSize = 0;

    // If all x-coordinates are the same but not all y-coordinates
    if (allXAreSame && !allYAreSame) {
        // Calculate meanY
        for (int i = 0; i < n; i++) {
            meanY += P[i].y;
        }
        meanY /= n;

        // Count points for the left subset based on y-coordinates
        for (int i = 0; i < n; i++) {
            if (P[i].y <= meanY) {
                leftSize++;
            }
        }
    } else if (allXAreSame && allYAreSame) {
        // If both all x-coordinates and y-coordinates are the same, split the array into two halves
        leftSize = n / 2; // This will be the size of the left subset
    } else {
        // Count points for the left subset based on x-coordinates
        for (int i = 0; i < n; i++) {
            if (P[i].x <= meanX) {
                leftSize++;
            }
        }
    }

    // Allocate memory for the split arrays based on the mean
    int lSize = leftSize == 1 ? 2 : leftSize;
    Point Pyl[lSize];        // Points with x-coordinate less than or equal to mean
    int rsize = n - leftSize == 1 ? 2 : n - leftSize;
    Point Pyr[rsize];    // Points with x-coordinate greater than mean

    int indexLeft = 0; // Index for the left array
    int indexRight = 0; // Index for the right array
    // Fill the left and right arrays based on the x-coordinate
    if (!allXAreSame || (allXAreSame && allYAreSame)) {
        for (int i = 0; i < n; i++) {
            if (P[i].x <= meanX) {
                Pyl[indexLeft++] = P[i];
            } else {
                Pyr[indexRight++] = P[i];
            }
        }
    } else {
        // Fill the left and right arrays based on the y-coordinate
        for (int i = 0; i < n; i++) {
            if (P[i].y <= meanY) {
                Pyl[indexLeft++] = P[i];
            } else {
                Pyr[indexRight++] = P[i];
            }
        }
    }
    if (indexLeft > 0 && indexLeft < lSize) {
        Point p;
        p.x = FLT_MAX;
        p.y = FLT_MAX;
        Pyl[indexLeft] = p; // Assumes Pyr has at least one element
    }

    // Check if the last element of Pyr is uninitialized
    if (indexRight > 0 && indexRight < rsize) {
        Point p;
        p.x = FLT_MAX;
        p.y = FLT_MAX;
        Pyr[indexRight] = p; // Assumes Pyl has at least one element
    }

    pid_t pid_left, pid_right;

    ClosestPair p3 = findClosestPairArbitrary(Pyl, lSize, Pyr, rsize);

    int pipe_left[2], result_left[2];
    int pipe_right[2], result_right[2];
    create_pipe(pipe_left);
    create_pipe(result_left);
    create_process(&pid_left);


    if (pid_left == 0) {
        close(pipe_left[WRITE_END]);
        close(result_left[READ_END]);
        setup_child(pipe_left, result_left);
        execute_child_program();
    }

    create_pipe(pipe_right);
    create_pipe(result_right);
    create_process(&pid_right);


    if (pid_right == 0) {
        close(pipe_right[WRITE_END]);
        close(result_right[READ_END]);
        setup_child(pipe_right, result_right);
        execute_child_program();
    }

    write_data_to_pipe(pipe_left, Pyl, lSize);
    write_data_to_pipe(pipe_right, Pyr, rsize);


    close(pipe_left[WRITE_END]);
    close(pipe_right[WRITE_END]);


    // Wait for child processes to finish
    waitpid(pid_left, NULL, 0);
    waitpid(pid_right, NULL, 0);
    close(pipe_left[READ_END]);
    close(pipe_right[READ_END]);
    close(result_left[WRITE_END]);
    close(result_right[WRITE_END]);

    ClosestPair cl, cr;

    // Now you can safely read from the result pipes
    cl = read_result_from_pipe(result_left[READ_END], lSize, rsize);
    cr = read_result_from_pipe(result_right[READ_END], lSize, rsize);
    close(result_left[READ_END]);
    close(result_right[READ_END]);
    ClosestPair closestP = findClosestPair(cl.p1, cl.p2, cr.p1, cr.p2);
    return p3.distance < closestP.distance ? p3 : closestP;
}


int main(void) {
    Point *points = NULL;
    int num_points = read_points(&points);

    if (num_points < 0) {
        ///fprintf(stderr, "Failed to read the points.\n");
        return EXIT_FAILURE;
    }

    // If no points were read, exit the program
    if (num_points == 0) {
        //fprintf(stderr, "No points were read from the input.\n");
        return EXIT_FAILURE;
    }
    //recursion Killer
    if (num_points == 1) {
        fflush(stdout);
        return EXIT_SUCCESS;
    }

    //recursion Killer
    if (num_points == 2) {
//        fprintf(stderr,"%.3f %.3f\n", points[0].x, points[0].y);
//        fprintf(stderr,"%.3f %.3f\n", points[1].x, points[1].y);
        //printf("%.3f %.3f\n", points[0].x, points[0].y);
        //printf("%.3f %.3f\n", points[1].x, points[1].y);

        if (points[0].x < points[1].x) {
            printf("%.3f %.3f\n", points[0].x, points[0].y);
            printf("%.3f %.3f\n", points[1].x, points[1].y);
            fflush(stdout);
            return EXIT_SUCCESS;
        } else if (points[0].x == points[1].x) {
            if (points[0].y < points[1].y) {
                printf("%.3f %.3f\n", points[0].x, points[0].y);
                printf("%.3f %.3f\n", points[1].x, points[1].y);
                fflush(stdout);
                return EXIT_SUCCESS;
            } else {
                printf("%.3f %.3f\n", points[1].x, points[1].y);
                printf("%.3f %.3f\n", points[0].x, points[0].y);
                fflush(stdout);
                return EXIT_SUCCESS;
            }
        } else {
            printf("%.3f %.3f\n", points[1].x, points[1].y);
            printf("%.3f %.3f\n", points[0].x, points[0].y);
            fflush(stdout);
            return EXIT_SUCCESS;
        }

    }


    // Find the closest pair of points
    ClosestPair closestPairResult = closestPair(points, num_points);

    // is this un
    if (closestPairResult.p1.x < closestPairResult.p2.x) {
        printf("%.3f %.3f\n", closestPairResult.p1.x, closestPairResult.p1.y);
        printf("%.3f %.3f\n", closestPairResult.p2.x, closestPairResult.p2.y);
    } else if (closestPairResult.p1.x == closestPairResult.p2.x) {
        if (closestPairResult.p1.y < closestPairResult.p2.y) {
            printf("%.3f %.3f\n", closestPairResult.p1.x, closestPairResult.p1.y);
            printf("%.3f %.3f\n", closestPairResult.p2.x, closestPairResult.p2.y);
            fflush(stdout);
            return EXIT_SUCCESS;
        } else {

            printf("%.3f %.3f\n", closestPairResult.p2.x, closestPairResult.p2.y);
            printf("%.3f %.3f\n", closestPairResult.p1.x, closestPairResult.p1.y);
            fflush(stdout);
            return EXIT_SUCCESS;
        }
    } else {
        printf("%.3f %.3f\n", closestPairResult.p2.x, closestPairResult.p2.y);
        printf("%.3f %.3f\n", closestPairResult.p1.x, closestPairResult.p1.y);
    }
    // Output the result
    // Free allocated memory
    free(points);


    return 0;
}
